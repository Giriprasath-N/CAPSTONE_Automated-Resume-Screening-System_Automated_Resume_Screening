import React from 'react';
import {
  FileText,
  Mail,
  Scale,
  Clock,
  Briefcase,
  GraduationCap
} from 'lucide-react';
import type { Candidate } from '../types/resume';

interface CandidateCardProps {
  candidate: Candidate;
  onSelect: (candidate: Candidate) => void;
  onToggleCompare: (candidate: Candidate) => void;
  isCompared: boolean;
  onOpenEmail: (candidate: Candidate) => void;
}

export const CandidateCard: React.FC<CandidateCardProps> = ({
  candidate,
  onSelect,
  onToggleCompare,
  isCompared,
  onOpenEmail
}) => {
  const { scores, evaluation } = candidate;

  // Status color styles
  const getStatusBadge = (status: Candidate['evaluation']['status']) => {
    switch (status) {
      case 'Top Shortlist':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'Strong Match':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
      case 'Potential Match':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'Unsuitable':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/30';
    }
  };

  const scoreColor =
    scores.overallScore >= 85
      ? 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10'
      : scores.overallScore >= 75
      ? 'text-blue-400 border-blue-500/40 bg-blue-500/10'
      : scores.overallScore >= 60
      ? 'text-amber-400 border-amber-500/40 bg-amber-500/10'
      : 'text-rose-400 border-rose-500/40 bg-rose-500/10';

  const coreMatched = candidate.skillMatches.filter(m => m.isCore && m.matched);
  const coreMissing = candidate.skillMatches.filter(m => m.isCore && !m.matched);

  return (
    <div className="glass-panel rounded-2xl p-5 border border-slate-800 hover:border-blue-500/40 transition duration-200 shadow-xl flex flex-col justify-between group">
      
      {/* Top Header: Score & Name & Status */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            {/* Score Badge */}
            <div className={`h-12 w-12 rounded-2xl border-2 flex flex-col items-center justify-center font-bold text-base shrink-0 shadow-lg ${scoreColor}`}>
              <span>{scores.overallScore}%</span>
              <span className="text-[9px] font-semibold uppercase opacity-80 -mt-1">Match</span>
            </div>

            <div>
              <h3 className="font-bold text-slate-100 text-base group-hover:text-blue-400 transition">
                {candidate.name}
              </h3>
              <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                <Briefcase className="h-3 w-3 text-slate-500" />
                {candidate.currentRole || 'Professional'}
              </p>
            </div>
          </div>

          {/* Status Badge */}
          <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full border ${getStatusBadge(evaluation.status)} shrink-0`}>
            {evaluation.status}
          </span>
        </div>

        {/* Candidate Info Chips */}
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mb-4 pb-3 border-b border-slate-800/80">
          <span className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5 text-blue-400" />
            {candidate.yearsOfExperience} YOE
          </span>
          <span className="flex items-center gap-1">
            <GraduationCap className="h-3.5 w-3.5 text-indigo-400" />
            {candidate.education}
          </span>
        </div>

        {/* Core Skills Match Summary */}
        <div className="space-y-2 mb-4">
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
              <span>Matched Core Skills ({coreMatched.length})</span>
              <span className="text-xs text-emerald-400 font-bold">{scores.skillsScore}% Skill Fit</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {coreMatched.map(m => (
                <span
                  key={m.skill}
                  className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-medium"
                >
                  ✓ {m.skill}
                </span>
              ))}
              {coreMatched.length === 0 && (
                <span className="text-xs text-slate-500 italic">No core skills matched</span>
              )}
            </div>
          </div>

          {coreMissing.length > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                Missing Core Requirements ({coreMissing.length})
              </div>
              <div className="flex flex-wrap gap-1">
                {coreMissing.slice(0, 3).map(m => (
                  <span
                    key={m.skill}
                    className="text-[11px] px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20 font-medium"
                  >
                    ✗ {m.skill}
                  </span>
                ))}
                {coreMissing.length > 3 && (
                  <span className="text-[11px] text-slate-500">+{coreMissing.length - 3} more</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Executive Summary Teaser */}
        <p className="text-xs text-slate-300 line-clamp-2 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 mb-4 italic">
          "{evaluation.executiveSummary}"
        </p>
      </div>

      {/* Card Actions Footer */}
      <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-800/80">
        <button
          onClick={() => onSelect(candidate)}
          className="flex-1 py-2 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
        >
          <FileText className="h-3.5 w-3.5" />
          <span>Resume & Analysis</span>
        </button>

        <button
          onClick={() => onToggleCompare(candidate)}
          className={`p-2 rounded-xl text-xs font-medium border transition ${
            isCompared
              ? 'bg-amber-500/20 text-amber-400 border-amber-500/50'
              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
          }`}
          title={isCompared ? 'Remove from Comparison' : 'Add to Side-by-Side Comparison'}
        >
          <Scale className="h-4 w-4" />
        </button>

        <button
          onClick={() => onOpenEmail(candidate)}
          className="p-2 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 hover:text-white transition"
          title="Generate Outreach Email"
        >
          <Mail className="h-4 w-4" />
        </button>
      </div>

    </div>
  );
};
