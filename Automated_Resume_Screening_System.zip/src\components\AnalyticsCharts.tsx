import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Cell
} from 'recharts';
import type { Candidate, JobRequirement } from '../types/resume';
import { Award, BarChart2 } from 'lucide-react';

interface AnalyticsChartsProps {
  candidates: Candidate[];
  job: JobRequirement;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({ candidates, job }) => {
  if (candidates.length === 0) {
    return (
      <div className="glass-panel rounded-2xl p-12 text-center text-slate-400 border border-slate-800">
        <BarChart2 className="h-12 w-12 text-slate-600 mx-auto mb-3" />
        <p className="text-sm font-semibold text-slate-200">No Candidate Data Available</p>
        <p className="text-xs text-slate-500 mt-1">Upload candidate resumes to visualize fit analytics and skill coverage charts.</p>
      </div>
    );
  }

  // 1. Score Range Distribution Data
  const scoreBuckets = [
    { range: '90-100% (Top)', count: 0, fill: '#10b981' },
    { range: '80-89% (Strong)', count: 0, fill: '#3b82f6' },
    { range: '70-79% (Good)', count: 0, fill: '#6366f1' },
    { range: '60-69% (Fair)', count: 0, fill: '#f59e0b' },
    { range: '< 60% (Unsuitable)', count: 0, fill: '#f43f5e' }
  ];

  candidates.forEach(c => {
    const s = c.scores.overallScore;
    if (s >= 90) scoreBuckets[0].count++;
    else if (s >= 80) scoreBuckets[1].count++;
    else if (s >= 70) scoreBuckets[2].count++;
    else if (s >= 60) scoreBuckets[3].count++;
    else scoreBuckets[4].count++;
  });

  // 2. Skill Coverage Frequency Data across all candidates
  const skillCoverageData = job.requiredSkills.map(skill => {
    const matchedCount = candidates.filter(c => 
      c.skillMatches.some(m => m.skill.toLowerCase() === skill.toLowerCase() && m.matched)
    ).length;
    const percentage = Math.round((matchedCount / candidates.length) * 100);
    return {
      skill,
      coverage: percentage,
      matchedCandidates: matchedCount
    };
  });

  // Average Sub-scores
  const avgSkills = Math.round(candidates.reduce((a, b) => a + b.scores.skillsScore, 0) / candidates.length);
  const avgExp = Math.round(candidates.reduce((a, b) => a + b.scores.experienceScore, 0) / candidates.length);
  const avgEdu = Math.round(candidates.reduce((a, b) => a + b.scores.educationScore, 0) / candidates.length);
  const avgKeyword = Math.round(candidates.reduce((a, b) => a + b.scores.keywordScore, 0) / candidates.length);

  return (
    <div className="space-y-6">
      
      {/* Metric Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <p className="text-xs text-slate-400 font-semibold">Avg Technical Skills Fit</p>
          <p className="text-2xl font-bold text-emerald-400 mt-1">{avgSkills}%</p>
        </div>
        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <p className="text-xs text-slate-400 font-semibold">Avg Experience Match</p>
          <p className="text-2xl font-bold text-blue-400 mt-1">{avgExp}%</p>
        </div>
        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <p className="text-xs text-slate-400 font-semibold">Avg Education Fit</p>
          <p className="text-2xl font-bold text-indigo-400 mt-1">{avgEdu}%</p>
        </div>
        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <p className="text-xs text-slate-400 font-semibold">Avg Cosine Keyword Similarity</p>
          <p className="text-2xl font-bold text-amber-400 mt-1">{avgKeyword}%</p>
        </div>
      </div>

      {/* Two Column Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Score Distribution Bar Chart */}
        <div className="glass-panel rounded-2xl p-5 border border-slate-800">
          <h3 className="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <BarChart2 className="h-4 w-4 text-blue-400" />
            Candidate Score Distribution
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scoreBuckets} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis dataKey="range" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {scoreBuckets.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Skill Coverage Radar Chart */}
        <div className="glass-panel rounded-2xl p-5 border border-slate-800">
          <h3 className="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <Award className="h-4 w-4 text-emerald-400" />
            Core Required Skill Coverage (%)
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={skillCoverageData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="skill" stroke="#cbd5e1" fontSize={10} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#64748b" fontSize={9} />
                <Radar name="Candidate Pool Coverage" dataKey="coverage" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.4} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
};
