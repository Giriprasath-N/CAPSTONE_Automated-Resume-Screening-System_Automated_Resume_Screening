import type { Candidate, JobRequirement } from '../types/resume';

export function exportCandidatesToCSV(candidates: Candidate[], job: JobRequirement) {
  const headers = [
    'Candidate Name',
    'Email',
    'Phone',
    'Current Role',
    'Years of Experience',
    'Overall Fit Score (%)',
    'Shortlist Status',
    'Skills Match Score',
    'Experience Match Score',
    'Education Score',
    'Matched Core Skills',
    'Missing Core Skills',
    'Executive Summary'
  ];

  const rows = candidates.map(c => {
    const matchedCore = c.skillMatches.filter(m => m.isCore && m.matched).map(m => m.skill).join('; ');
    const missingCore = c.skillMatches.filter(m => m.isCore && !m.matched).map(m => m.skill).join('; ');

    return [
      `"${c.name}"`,
      `"${c.email}"`,
      `"${c.phone || ''}"`,
      `"${c.currentRole || ''}"`,
      c.yearsOfExperience,
      `${c.scores.overallScore}%`,
      `"${c.evaluation.status}"`,
      `${c.scores.skillsScore}%`,
      `${c.scores.experienceScore}%`,
      `${c.scores.educationScore}%`,
      `"${matchedCore}"`,
      `"${missingCore}"`,
      `"${c.evaluation.executiveSummary.replace(/"/g, '""')}"`
    ].join(',');
  });

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `Candidate_Shortlist_${job.title.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportCandidatesToJSON(candidates: Candidate[], job: JobRequirement) {
  const exportData = {
    jobTitle: job.title,
    exportedDate: new Date().toISOString(),
    totalCandidates: candidates.length,
    shortlistedCount: candidates.filter(c => c.shortlisted).length,
    candidates: candidates.map(c => ({
      name: c.name,
      email: c.email,
      phone: c.phone,
      location: c.location,
      currentRole: c.currentRole,
      yearsOfExperience: c.yearsOfExperience,
      overallScore: c.scores.overallScore,
      status: c.evaluation.status,
      scores: c.scores,
      skillMatches: c.skillMatches,
      strengths: c.evaluation.strengths,
      gaps: c.evaluation.gaps,
      executiveSummary: c.evaluation.executiveSummary
    }))
  };

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportData, null, 2));
  const link = document.createElement('a');
  link.setAttribute('href', dataStr);
  link.setAttribute('download', `Candidate_Shortlist_${job.title.replace(/\s+/g, '_')}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
