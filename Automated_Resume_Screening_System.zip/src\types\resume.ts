export interface JobRequirement {
  id: string;
  title: string;
  department: string;
  location: string;
  employmentType: 'Full-Time' | 'Part-Time' | 'Contract' | 'Remote';
  minExperienceYears: number;
  maxExperienceYears?: number;
  requiredSkills: string[];
  preferredSkills: string[];
  requiredEducation: string; // e.g. "Bachelor's in Computer Science or related field"
  description: string;
  createdDate: string;
}

export interface CandidateSkillMatch {
  skill: string;
  matched: boolean;
  isCore: boolean;
  confidence: number; // 0-100
}

export interface ScoreBreakdown {
  skillsScore: number;       // 0-100
  experienceScore: number;   // 0-100
  educationScore: number;    // 0-100
  keywordScore: number;      // 0-100 (TF-IDF / Cosine Similarity)
  overallScore: number;      // 0-100 weighted
}

export interface RedFlag {
  type: 'gap' | 'missing_core' | 'short_tenure' | 'education_mismatch';
  severity: 'low' | 'medium' | 'high';
  description: string;
}

export interface CandidateEvaluation {
  status: 'Top Shortlist' | 'Strong Match' | 'Potential Match' | 'Unsuitable';
  executiveSummary: string;
  strengths: string[];
  gaps: string[];
  redFlags: RedFlag[];
  suggestedInterviewQuestions: string[];
  recommendedRole?: string;
}

export interface Candidate {
  id: string;
  name: string;
  email: string;
  phone?: string;
  location?: string;
  currentRole?: string;
  yearsOfExperience: number;
  education: string;
  skills: string[];
  resumeText: string;
  fileFormat: 'pdf' | 'docx' | 'txt' | 'sample';
  appliedDate: string;
  scores: ScoreBreakdown;
  skillMatches: CandidateSkillMatch[];
  evaluation: CandidateEvaluation;
  shortlisted: boolean;
}

export interface ScoringWeights {
  skills: number;       // default 0.40
  experience: number;   // default 0.30
  education: number;    // default 0.15
  keywords: number;     // default 0.15
  shortlistThreshold: number; // default 75%
}

export interface JobTemplate {
  id: string;
  name: string;
  job: JobRequirement;
}
