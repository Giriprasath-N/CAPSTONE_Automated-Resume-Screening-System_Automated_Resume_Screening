import React, { useState } from 'react';
import {
  Search,
  ArrowUpDown,
  Users
} from 'lucide-react';
import type { Candidate, JobRequirement } from '../types/resume';
import { CandidateCard } from './CandidateCard';

interface DashboardProps {
  job: JobRequirement;
  candidates: Candidate[];
  onSelectCandidate: (candidate: Candidate) => void;
  onToggleCompare: (candidate: Candidate) => void;
  comparedIds: string[];
  onOpenEmail: (candidate: Candidate) => void;
  onOpenJobForm: () => void;
  onOpenWeightsModal: () => void;
  shortlistCutoff: number;
}

export const Dashboard: React.FC<DashboardProps> = ({
  job,
  candidates,
  onSelectCandidate,
  onToggleCompare,
  comparedIds,
  onOpenEmail,
  onOpenJobForm,
  shortlistCutoff
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'score' | 'experience' | 'name'>('score');

  // Filter & Sort candidates
  const filteredCandidates = candidates.filter(c => {
    // Search query
    const matchSearch =
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.currentRole && c.currentRole.toLowerCase().includes(searchTerm.toLowerCase())) ||
      c.skills.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));

    // Status filter
    const matchStatus =
      statusFilter === 'All'
        ? true
        : statusFilter === 'Shortlisted'
        ? c.shortlisted
        : c.evaluation.status === statusFilter;

    return matchSearch && matchStatus;
  });

  const sortedCandidates = [...filteredCandidates].sort((a, b) => {
    if (sortBy === 'score') return b.scores.overallScore - a.scores.overallScore;
    if (sortBy === 'experience') return b.yearsOfExperience - a.yearsOfExperience;
    return a.name.localeCompare(b.name);
  });

  const shortlistedCount = candidates.filter(c => c.shortlisted).length;

  return (
    <div className="space-y-6">
      
      {/* Active Job Target Banner */}
      <div className="glass-panel-glow rounded-2xl p-6 border border-blue-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                Active Job Profile
              </span>
              <span className="text-xs text-slate-400">• {job.department} • {job.employmentType}</span>
            </div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-3">
              {job.title}
              <button
                onClick={onOpenJobForm}
                className="text-xs text-blue-400 hover:text-blue-300 font-medium underline font-sans ml-2"
              >
                Edit Specs
              </button>
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-3xl line-clamp-2">
              {job.description}
            </p>

            {/* Core Tech Stack Tags */}
            <div className="flex flex-wrap items-center gap-1.5 mt-3">
              <span className="text-[11px] font-semibold text-slate-400 mr-1">Required Skills:</span>
              {job.requiredSkills.map(s => (
                <span key={s} className="text-[11px] px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-300 border border-blue-500/20 font-medium">
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Quick Metrics Badge Group */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-center">
              <p className="text-[10px] text-slate-400 uppercase font-semibold">Total Scanned</p>
              <p className="text-xl font-bold text-slate-100">{candidates.length}</p>
            </div>
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-center">
              <p className="text-[10px] text-emerald-400 uppercase font-semibold">Shortlisted (≥{shortlistCutoff}%)</p>
              <p className="text-xl font-bold text-emerald-300">{shortlistedCount}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Candidate Filtering & Search Toolbar */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Search Input */}
        <div className="relative flex-1 w-full">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search candidates by name, role, or skill..."
            className="w-full pl-9 pr-4 py-2 bg-slate-900/90 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 text-xs">
          {['All', 'Shortlisted', 'Top Shortlist', 'Strong Match', 'Potential Match', 'Unsuitable'].map(status => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition ${
                statusFilter === status
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {status}
            </button>
          ))}
        </div>

        {/* Sort Dropdown */}
        <div className="flex items-center gap-2 shrink-0">
          <ArrowUpDown className="h-3.5 w-3.5 text-slate-400" />
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="py-1.5 pl-2.5 pr-7 text-xs bg-slate-900/90 border border-slate-700/80 rounded-xl text-slate-200 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="score">Sort by Fit Score (High → Low)</option>
            <option value="experience">Sort by Experience (YOE)</option>
            <option value="name">Sort Alphabetically (A → Z)</option>
          </select>
        </div>

      </div>

      {/* Candidate Grid */}
      {sortedCandidates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedCandidates.map(candidate => (
            <CandidateCard
              key={candidate.id}
              candidate={candidate}
              onSelect={onSelectCandidate}
              onToggleCompare={onToggleCompare}
              isCompared={comparedIds.includes(candidate.id)}
              onOpenEmail={onOpenEmail}
            />
          ))}
        </div>
      ) : (
        <div className="glass-panel rounded-2xl p-12 text-center border border-slate-800">
          <Users className="h-12 w-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-200">No Candidates Found</h3>
          <p className="text-xs text-slate-400 mt-1 mb-4">
            Try adjusting your search query, status filters, or upload new resumes.
          </p>
        </div>
      )}

    </div>
  );
};
