import type { JobRequirement, ScoringWeights } from '../types/resume';

export const DEFAULT_WEIGHTS: ScoringWeights = {
  skills: 0.40,
  experience: 0.30,
  education: 0.15,
  keywords: 0.15,
  shortlistThreshold: 75,
};

export const MOCK_JOBS: JobRequirement[] = [
  {
    id: 'job-1',
    title: 'Senior Full Stack AI Engineer',
    department: 'Engineering',
    location: 'San Francisco, CA / Remote',
    employmentType: 'Full-Time',
    minExperienceYears: 5,
    maxExperienceYears: 10,
    requiredSkills: [
      'React',
      'TypeScript',
      'Node.js',
      'Python',
      'LLM',
      'REST APIs',
      'PostgreSQL',
      'Git'
    ],
    preferredSkills: [
      'Docker',
      'Kubernetes',
      'GraphQL',
      'Tailwind CSS',
      'Vector Databases',
      'LangChain',
      'AWS'
    ],
    requiredEducation: "Bachelor's degree in Computer Science, Software Engineering, or equivalent experience",
    description: `We are looking for a Senior Full Stack AI Engineer to lead the architecture and development of our next-generation AI-powered enterprise SaaS application. In this role, you will build responsive frontend interfaces using React & TypeScript, design scalable backend microservices with Python and Node.js, and integrate Large Language Models (LLMs) and vector embeddings for generative search and automated workflows.

Responsibilities:
- Architect and develop end-to-end web applications with React, TypeScript, Node.js, and Python.
- Integrate state-of-the-art AI models (OpenAI, Gemini, Anthropic) into core product workflows.
- Design high-performance PostgreSQL database schemas and optimized RESTful APIs.
- Collaborate with product managers and UX designers to build intuitive user interfaces.
- Mentor junior engineers and enforce code quality, unit testing, and CI/CD best practices.`,
    createdDate: '2026-08-20',
  },
  {
    id: 'job-2',
    title: 'Senior Product Manager - AI & Data Platform',
    department: 'Product',
    location: 'New York, NY / Hybrid',
    employmentType: 'Full-Time',
    minExperienceYears: 6,
    requiredSkills: [
      'Product Strategy',
      'Agile / Scrum',
      'Data Analytics',
      'User Research',
      'Roadmapping',
      'SQL',
      'A/B Testing'
    ],
    preferredSkills: [
      'AI Product Design',
      'Jira',
      'Mixpanel',
      'SaaS Metrics',
      'Machine Learning Concepts'
    ],
    requiredEducation: "Bachelor's or Master's degree in Business, Computer Science, or related field",
    description: `Seeking a data-driven Senior Product Manager to drive product strategy for our flagship AI Analytics platform. You will collaborate closely with AI researchers, engineers, and enterprise customers to define product roadmap, launch innovative features, and measure product-market fit.`,
    createdDate: '2026-08-22',
  },
  {
    id: 'job-3',
    title: 'Lead Data Scientist / ML Engineer',
    department: 'Data Science',
    location: 'Austin, TX / Remote',
    employmentType: 'Full-Time',
    minExperienceYears: 4,
    requiredSkills: [
      'Python',
      'PyTorch',
      'Machine Learning',
      'NLP',
      'SQL',
      'Scikit-learn',
      'Pandas'
    ],
    preferredSkills: [
      'Transformers',
      'BERT / GPT',
      'Deep Learning',
      'MLOps',
      'Docker',
      'FastAPI'
    ],
    requiredEducation: "Master's or Ph.D. in Computer Science, Data Science, Statistics, or Quantitative field",
    description: `Join our AI Lab to build cutting-edge Natural Language Processing (NLP) models, automated text classification, and recommendation engines. You will handle large-scale datasets, fine-tune transformer models, and deploy scalable ML APIs to production.`,
    createdDate: '2026-08-25',
  }
];

export interface SampleCandidateInput {
  name: string;
  email: string;
  phone: string;
  location: string;
  currentRole: string;
  yearsOfExperience: number;
  education: string;
  skills: string[];
  resumeText: string;
}

export const SAMPLE_CANDIDATES_RAW: SampleCandidateInput[] = [
  {
    name: 'Elena Rostova',
    email: 'elena.rostova@techmail.com',
    phone: '+1 (555) 234-8901',
    location: 'San Francisco, CA',
    currentRole: 'Senior Full Stack AI Developer at CloudScale Inc.',
    yearsOfExperience: 7,
    education: 'B.S. in Computer Science, UC Berkeley (2019)',
    skills: [
      'React', 'TypeScript', 'Node.js', 'Python', 'LLM', 'REST APIs',
      'PostgreSQL', 'Git', 'Docker', 'Tailwind CSS', 'Vector Databases', 'LangChain', 'AWS'
    ],
    resumeText: `ELENA ROSTOVA
San Francisco, CA | elena.rostova@techmail.com | +1 (555) 234-8901 | linkedin.com/in/elenarostova

SUMMARY
Senior Full Stack AI Engineer with 7 years of hands-on experience building high-throughput web platforms, scalable microservices, and AI-driven features. Deep expertise in React, TypeScript, Node.js, Python, and integrating LLMs for automated enterprise solutions.

EXPERIENCE
CloudScale Inc. | Senior Full Stack AI Engineer | 2022 - Present (San Francisco, CA)
- Led a team of 5 engineers building an AI-powered enterprise analytics dashboard using React, TypeScript, and Tailwind CSS.
- Architected Python backend microservices utilizing FastAPI and PostgreSQL, serving 500k+ daily active API calls.
- Integrated OpenAI and Google Gemini LLMs with Vector Databases (Pinecone, ChromaDB) to power semantic natural language search.
- Streamlined deployment pipelines with Docker, AWS Lambda, and GitHub Actions, reducing deployment time by 40%.

Nexus Software | Full Stack Developer | 2019 - 2022 (San Jose, CA)
- Built responsive user interfaces with React and Redux, connected to Node.js / Express REST APIs.
- Designed database schemas and optimized SQL queries in PostgreSQL and MongoDB.
- Implemented automated CI/CD pipelines and unit testing with Jest and Cypress.

EDUCATION
Bachelor of Science in Computer Science | UC Berkeley (Graduated 2019, Magna Cum Laude)

SKILLS & CERTIFICATIONS
Languages: TypeScript, JavaScript, Python, SQL, HTML5, CSS3
Frontend: React, Next.js, Redux, Tailwind CSS, Vite
Backend: Node.js, Express, Python, FastAPI, Django, REST APIs, GraphQL
Databases & Cloud: PostgreSQL, MongoDB, Redis, Vector Databases, AWS (EC2, S3, Lambda), Docker, Git
AI / ML: LLMs, LangChain, RAG architecture, Prompt Engineering`
  },
  {
    name: 'Marcus Vance',
    email: 'marcus.vance@devstudio.io',
    phone: '+1 (555) 345-6789',
    location: 'Austin, TX',
    currentRole: 'Lead Software Engineer at NextGen Systems',
    yearsOfExperience: 6,
    education: 'M.S. in Software Engineering, UT Austin (2020)',
    skills: [
      'React', 'TypeScript', 'Node.js', 'Python', 'REST APIs',
      'PostgreSQL', 'Git', 'Docker', 'Kubernetes', 'AWS', 'GraphQL'
    ],
    resumeText: `MARCUS VANCE
Austin, TX | marcus.vance@devstudio.io | +1 (555) 345-6789

PROFESSIONAL SUMMARY
Experienced Lead Software Engineer with 6 years specializing in frontend and backend web architecture. Proficient in TypeScript, React, Node.js, Python, REST APIs, and Cloud Infrastructure (AWS, Kubernetes, Docker). Passionate about building robust systems and clean code.

EXPERIENCE
NextGen Systems | Lead Software Engineer | 2021 - Present
- Designed scalable web microservices using Node.js, Express, and PostgreSQL.
- Developed complex web interfaces with React, TypeScript, and modern state management.
- Containerized microservices using Docker and orchestrated deployments on Kubernetes clusters on AWS.
- Conducted code reviews and maintained high test coverage (85%+) using Jest and PyTest.

Apex Digital | Backend Developer | 2018 - 2021
- Created RESTful and GraphQL APIs using Python (Flask) and PostgreSQL.
- Optimized database indexing and query execution times by 35%.

EDUCATION
Master of Science in Software Engineering | UT Austin (2020)
Bachelor of Science in Computer Engineering | Texas A&M (2018)

SKILLS
React, TypeScript, JavaScript, Node.js, Python, PostgreSQL, REST APIs, GraphQL, Docker, Kubernetes, AWS, Git`
  },
  {
    name: 'Sarah Jenkins',
    email: 'sjenkins.data@analytics.net',
    phone: '+1 (555) 890-1234',
    location: 'Seattle, WA',
    currentRole: 'Staff NLP & Data Scientist at DataPulse AI',
    yearsOfExperience: 5,
    education: 'M.S. in Data Science, University of Washington (2021)',
    skills: [
      'Python', 'PyTorch', 'Machine Learning', 'NLP', 'SQL',
      'Scikit-learn', 'Pandas', 'Transformers', 'BERT / GPT', 'Deep Learning', 'FastAPI', 'Git'
    ],
    resumeText: `SARAH JENKINS
Seattle, WA | sjenkins.data@analytics.net | +1 (555) 890-1234

SUMMARY
Data Scientist and Natural Language Processing (NLP) Specialist with 5 years of industry experience developing machine learning pipelines, fine-tuning transformer models, and writing high-performance Python applications.

EXPERIENCE
DataPulse AI | Staff Data Scientist (NLP) | 2022 - Present
- Trained transformer-based models (BERT, RoBERTa) for sentiment analysis and document classification.
- Built data processing pipelines handling terabytes of text using Python, Pandas, PyTorch, and SQL.
- Deployed ML model endpoints via FastAPI microservices wrapped in Docker containers.

Innovate AI Labs | Machine Learning Engineer | 2019 - 2022
- Developed custom feature extraction algorithms using Scikit-learn and NLTK.
- Built automated text extraction tools and TF-IDF similarity rankers for HR resume processing.

EDUCATION
M.S. in Data Science | University of Washington (2021)
B.S. in Statistics | Washington State University (2019)

SKILLS
Python, PyTorch, TensorFlow, NLP, Machine Learning, Scikit-learn, Pandas, Transformers, Deep Learning, SQL, FastAPI, Docker, Git`
  },
  {
    name: 'David Chen',
    email: 'david.chen.web@gmail.com',
    phone: '+1 (555) 456-7890',
    location: 'Chicago, IL',
    currentRole: 'Junior Frontend Developer at WebCraft Studio',
    yearsOfExperience: 2,
    education: 'B.A. in Communications, DePaul University (2023)',
    skills: [
      'React', 'JavaScript', 'HTML5', 'CSS3', 'Git', 'Tailwind CSS'
    ],
    resumeText: `DAVID CHEN
Chicago, IL | david.chen.web@gmail.com | +1 (555) 456-7890

SUMMARY
Enthusiastic Junior Web Developer with 2 years of experience crafting interactive user interfaces using HTML, CSS, JavaScript, and React. Eager to expand skills into full-stack development and modern AI applications.

EXPERIENCE
WebCraft Studio | Junior Frontend Developer | 2023 - Present
- Created responsive marketing landing pages using HTML5, CSS3, JavaScript, and Tailwind CSS.
- Assisted in building client portal dashboards using React.
- Fixed UI bugs and maintained codebase version control with Git.

EDUCATION
B.A. in Communications | DePaul University (2023)
Full-Stack Web Coding Bootcamp Certificate (2023)

SKILLS
HTML5, CSS3, JavaScript, React, Tailwind CSS, Git`
  },
  {
    name: 'Aisha Patel',
    email: 'aisha.patel.pm@agilelead.com',
    phone: '+1 (555) 678-9012',
    location: 'New York, NY',
    currentRole: 'Senior Product Manager at FinTech Horizon',
    yearsOfExperience: 8,
    education: 'MBA, Columbia Business School (2018)',
    skills: [
      'Product Strategy', 'Agile / Scrum', 'Data Analytics', 'User Research',
      'Roadmapping', 'SQL', 'A/B Testing', 'AI Product Design', 'Jira', 'Mixpanel'
    ],
    resumeText: `AISHA PATEL
New York, NY | aisha.patel.pm@agilelead.com | +1 (555) 678-9012

EXECUTIVE SUMMARY
Senior Product Manager with 8 years of experience leading cross-functional engineering, design, and analytics teams to build market-leading SaaS products. Proven track record in product strategy, user research, data-driven roadmapping, and enterprise launches.

EXPERIENCE
FinTech Horizon | Senior Product Manager | 2021 - Present
- Spearheaded the launch of an AI-driven financial forecast tool, driving \$12M in annual recurring revenue (ARR).
- Managed Agile sprint execution for 14 cross-functional engineers and designers using Jira.
- Conducted extensive A/B testing and customer user research, increasing product conversion rate by 28%.
- Utilized SQL and Mixpanel to analyze user retention funnels and iterate on feature priorities.

EDUCATION
Master of Business Administration (MBA) | Columbia Business School (2018)
B.S. in Economics | NYU Stern (2016)

SKILLS
Product Strategy, Agile/Scrum, User Research, Roadmapping, Data Analytics, SQL, A/B Testing, Jira, Mixpanel, SaaS Metrics`
  }
];
