import React, { useState } from 'react';
import {
  X,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Award,
  Sparkles,
  Mail,
  HelpCircle,
  Brain,
  ShieldAlert,
  Loader2
} from 'lucide-react';
import type { Candidate, JobRequirement } from '../types/resume';
import { analyzeResumeWithGemini } from '../utils/geminiApi';

interface CandidateDetailModalProps {
  candidate: Candidate;
  job: JobRequirement;
  onClose: () => void;
  onOpenEmail: (candidate: Candidate) => void;
  geminiApiKey: string;
  onUpdateCandidateEvaluation: (candidateId: string, updatedEval: any) => void;
}

export const CandidateDetailModal: React.FC<CandidateDetailModalProps> = ({
  candidate,
  job,
  onClose,
  onOpenEmail,
  geminiApiKey,
  onUpdateCandidateEvaluation
}) => {
  const [activeTab, setActiveTab] = useState<'analysis' | 'resume'>('analysis');
  const [isGeminiRunning, setIsGeminiRunning] = useState(false);

  const { scores, evaluation, skillMatches } = candidate;

  // Run deep Gemini analysis if API key is present
  const handleRunGeminiAnalysis = async () => {
    if (!geminiApiKey) return;
    setIsGeminiRunning(true);
    const geminiResult = await analyzeResumeWithGemini(candidate.resumeText, job, geminiApiKey);
    if (geminiResult) {
      onUpdateCandidateEvaluation(candidate.id, {
        ...candidate.evaluation,
        ...geminiResult
      });
    }
    setIsGeminiRunning(false);
  };

  // Color code resume text with keyword highlights
  const renderHighlightedResume = (text: string) => {
    let highlighted = text;
    
    // Core matched skills -> Green highlight
    const matchedSkills = skillMatches.filter(m => m.matched).map(m => m.skill);
    matchedSkills.forEach(skill => {
      const escaped = skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`\\b(${escaped})\\b`, 'gi');
      highlighted = highlighted.replace(regex, `<mark class="bg-emerald-500/30 text-emerald-200 font-semibold px-1 rounded">$1</mark>`);
    });

    // Missing core skills -> Amber/Red inline highlight if present in resume context
    const missingSkills = skillMatches.filter(m => m.isCore && !m.matched).map(m => m.skill);
    missingSkills.forEach(skill => {
      const escaped = skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`\\b(${escaped})\\b`, 'gi');
      highlighted = highlighted.replace(regex, `<mark class="bg-rose-500/30 text-rose-200 font-semibold px-1 rounded">$1</mark>`);
    });

    return { __html: highlighted };
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="glass-panel w-full max-w-5xl rounded-2xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-800 animate-in fade-in zoom-in duration-200">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-lg">
              {scores.overallScore}%
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-xl font-bold text-white">{candidate.name}</h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30 font-semibold">
                  {evaluation.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {candidate.currentRole} • {candidate.yearsOfExperience} YOE • {candidate.email}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onOpenEmail(candidate)}
              className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-blue-600/20 transition"
            >
              <Mail className="h-4 w-4" />
              <span>Contact Candidate</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Tab Switcher & Score Bar */}
        <div className="bg-slate-900/90 px-6 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('analysis')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg font-semibold transition ${
                activeTab === 'analysis' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Brain className="h-3.5 w-3.5" />
              <span>AI Evaluation & Strengths</span>
            </button>
            <button
              onClick={() => setActiveTab('resume')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg font-semibold transition ${
                activeTab === 'resume' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="h-3.5 w-3.5" />
              <span>Resume Text & Highlights</span>
            </button>
          </div>

          {/* Sub-Score Breakdown Chips */}
          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1 text-slate-300">
              <span className="text-slate-500">Skill Fit:</span>
              <span className="font-bold text-emerald-400">{scores.skillsScore}%</span>
            </div>
            <div className="flex items-center gap-1 text-slate-300">
              <span className="text-slate-500">Experience:</span>
              <span className="font-bold text-blue-400">{scores.experienceScore}%</span>
            </div>
            <div className="flex items-center gap-1 text-slate-300">
              <span className="text-slate-500">Education:</span>
              <span className="font-bold text-indigo-400">{scores.educationScore}%</span>
            </div>
            <div className="flex items-center gap-1 text-slate-300">
              <span className="text-slate-500">Keyword Overlap:</span>
              <span className="font-bold text-amber-400">{scores.keywordScore}%</span>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-200 text-xs">
          
          {activeTab === 'analysis' ? (
            <div className="space-y-6">
              
              {/* Executive Summary */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 relative">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-amber-400" />
                    AI Recruiter Executive Summary
                  </h3>
                  {geminiApiKey && (
                    <button
                      onClick={handleRunGeminiAnalysis}
                      disabled={isGeminiRunning}
                      className="px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30 text-[11px] font-semibold border border-indigo-500/30 flex items-center gap-1"
                    >
                      {isGeminiRunning ? <Loader2 className="h-3 w-3 animate-spin" /> : <Brain className="h-3 w-3" />}
                      <span>Re-analyze with Gemini LLM</span>
                    </button>
                  )}
                </div>
                <p className="text-slate-300 leading-relaxed text-xs sm:text-sm">
                  {evaluation.executiveSummary}
                </p>
              </div>

              {/* Skills Matrix Grid */}
              <div>
                <h3 className="font-bold text-sm text-slate-100 mb-3 flex items-center gap-2">
                  <Award className="h-4 w-4 text-blue-400" />
                  Detailed Skill Matching Matrix
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {skillMatches.map(sm => (
                    <div
                      key={sm.skill}
                      className={`p-3 rounded-xl border flex items-center justify-between ${
                        sm.matched
                          ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-200'
                          : 'bg-slate-900/80 border-slate-800 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {sm.matched ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                        ) : (
                          <X className="h-4 w-4 text-rose-400 shrink-0" />
                        )}
                        <span className="font-medium text-xs text-slate-200">{sm.skill}</span>
                      </div>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                        sm.isCore ? 'bg-blue-500/20 text-blue-300' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {sm.isCore ? 'Core Required' : 'Preferred'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Strengths & Gaps Two Column */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                
                {/* Key Strengths */}
                <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/20">
                  <h4 className="font-bold text-sm text-emerald-300 mb-3 flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    Candidate Key Strengths
                  </h4>
                  <ul className="space-y-2">
                    {evaluation.strengths.map((st, i) => (
                      <li key={i} className="flex items-start gap-2 text-slate-200">
                        <span className="text-emerald-400 font-bold">•</span>
                        <span>{st}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Critical Gaps */}
                <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/20">
                  <h4 className="font-bold text-sm text-rose-300 mb-3 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-rose-400" />
                    Notable Gaps & Deficiencies
                  </h4>
                  <ul className="space-y-2">
                    {evaluation.gaps.map((gp, i) => (
                      <li key={i} className="flex items-start gap-2 text-slate-200">
                        <span className="text-rose-400 font-bold">•</span>
                        <span>{gp}</span>
                      </li>
                    ))}
                    {evaluation.gaps.length === 0 && (
                      <li className="text-slate-400 italic">No significant gaps detected!</li>
                    )}
                  </ul>
                </div>

              </div>

              {/* Red Flags & Anomalies */}
              {evaluation.redFlags.length > 0 && (
                <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/30">
                  <h4 className="font-bold text-sm text-amber-300 mb-2 flex items-center gap-2">
                    <ShieldAlert className="h-4 w-4 text-amber-400" />
                    Red Flags & Risk Assessment
                  </h4>
                  <div className="space-y-2">
                    {evaluation.redFlags.map((rf, i) => (
                      <div key={i} className="flex items-start gap-2 text-amber-200 text-xs">
                        <span className="px-1.5 py-0.5 rounded text-[10px] uppercase font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                          {rf.severity}
                        </span>
                        <span>{rf.description}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Tailored Interview Questions */}
              <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/30">
                <h4 className="font-bold text-sm text-indigo-300 mb-3 flex items-center gap-2">
                  <HelpCircle className="h-4 w-4 text-indigo-400" />
                  Recommended HR Interview Questions
                </h4>
                <div className="space-y-2">
                  {evaluation.suggestedInterviewQuestions.map((q, i) => (
                    <div key={i} className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-200">
                      <span className="font-bold text-indigo-400 mr-2">Q{i + 1}:</span>
                      {q}
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ) : (
            /* Highlighted Resume Text Tab */
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
                <span className="text-slate-400">Legend:</span>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-emerald-300 font-semibold">
                    <span className="h-2 w-2 rounded-full bg-emerald-400"></span> Matched Skill
                  </span>
                  <span className="flex items-center gap-1 text-rose-300 font-semibold">
                    <span className="h-2 w-2 rounded-full bg-rose-400"></span> Missing Core Skill
                  </span>
                </div>
              </div>

              <div
                className="p-6 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 whitespace-pre-wrap leading-relaxed select-text overflow-x-auto"
                dangerouslySetInnerHTML={renderHighlightedResume(candidate.resumeText)}
              />
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
