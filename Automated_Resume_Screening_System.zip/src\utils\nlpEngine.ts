import type {
  Candidate,
  CandidateEvaluation,
  CandidateSkillMatch,
  JobRequirement,
  RedFlag,
  ScoreBreakdown,
  ScoringWeights
} from '../types/resume';
import type { SampleCandidateInput } from './mockData';

// Common Stopwords to filter out for TF-IDF
const STOP_WORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and',
  'any', 'are', 'aren\'t', 'as', 'at', 'be', 'because', 'been', 'before', 'being',
  'below', 'between', 'both', 'but', 'by', 'can', 'cant', 'cannot', 'could',
  'did', 'do', 'does', 'doing', 'down', 'during', 'each', 'few', 'for', 'from',
  'further', 'had', 'has', 'have', 'having', 'he', 'her', 'here', 'hers',
  'herself', 'him', 'himself', 'his', 'how', 'i', 'if', 'in', 'into', 'is',
  'it', 'its', 'itself', 'just', 'me', 'more', 'most', 'my', 'myself', 'no',
  'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'our', 'ours',
  'ourselves', 'out', 'over', 'own', 'same', 'she', 'should', 'so', 'some',
  'such', 'than', 'that', 'the', 'their', 'theirs', 'them', 'themselves', 'then',
  'there', 'these', 'they', 'this', 'those', 'through', 'to', 'too', 'under',
  'until', 'up', 'very', 'was', 'we', 'were', 'what', 'when', 'where', 'which',
  'while', 'who', 'whom', 'why', 'with', 'would', 'you', 'your', 'yours',
  'yourself', 'yourselves', 'experience', 'worked', 'building', 'using'
]);

// Skill Synonyms Map for flexible NLP matching
const SKILL_SYNONYMS: Record<string, string[]> = {
  'react': ['reactjs', 'react.js', 'react framework'],
  'typescript': ['ts', 'type script'],
  'javascript': ['js', 'ecmascript'],
  'node.js': ['nodejs', 'node', 'express'],
  'python': ['python3', 'py'],
  'llm': ['llms', 'large language models', 'openai', 'gemini', 'gpt', 'anthropic'],
  'postgresql': ['postgres', 'pg', 'psql'],
  'rest apis': ['rest api', 'restful', 'restful apis', 'rest'],
  'aws': ['amazon web services', 'ec2', 's3', 'lambda'],
  'machine learning': ['ml', 'machine learning algorithms'],
  'nlp': ['natural language processing', 'text analytics'],
  'docker': ['containerization', 'containers'],
  'kubernetes': ['k8s'],
  'agile / scrum': ['agile', 'scrum', 'kanban'],
  'data analytics': ['analytics', 'bi', 'business intelligence'],
  'product strategy': ['product roadmap', 'product lifecycle'],
};

// Tokenize text into words
export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9+#.\s-]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 1 && !STOP_WORDS.has(w));
}

// Compute TF-IDF Cosine Similarity between two text documents
export function computeCosineSimilarity(text1: string, text2: string): number {
  const tokens1 = tokenize(text1);
  const tokens2 = tokenize(text2);

  if (tokens1.length === 0 || tokens2.length === 0) return 0;

  const freq1: Record<string, number> = {};
  const freq2: Record<string, number> = {};

  tokens1.forEach(t => { freq1[t] = (freq1[t] || 0) + 1; });
  tokens2.forEach(t => { freq2[t] = (freq2[t] || 0) + 1; });

  const allWords = new Set([...Object.keys(freq1), ...Object.keys(freq2)]);
  let dotProduct = 0;
  let mag1 = 0;
  let mag2 = 0;

  allWords.forEach(word => {
    const f1 = freq1[word] || 0;
    const f2 = freq2[word] || 0;
    dotProduct += f1 * f2;
    mag1 += f1 * f1;
    mag2 += f2 * f2;
  });

  if (mag1 === 0 || mag2 === 0) return 0;
  const similarity = dotProduct / (Math.sqrt(mag1) * Math.sqrt(mag2));
  return Math.min(100, Math.round(similarity * 100 * 2.5)); // Scale normalized similarity to percentage
}

// Check if a skill exists in candidate skills or resume text (with synonym support)
function containsSkill(skill: string, candidateSkills: string[], resumeTextLower: string): boolean {
  const normSkill = skill.toLowerCase().trim();

  // 1. Direct check in candidate skills list
  if (candidateSkills.some(s => s.toLowerCase().trim() === normSkill)) {
    return true;
  }

  // 2. Direct regex match in resume text
  const escapedSkill = normSkill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedSkill}\\b`, 'i');
  if (regex.test(resumeTextLower)) {
    return true;
  }

  // 3. Synonym check
  const synonyms = SKILL_SYNONYMS[normSkill] || [];
  for (const syn of synonyms) {
    if (candidateSkills.some(s => s.toLowerCase().includes(syn))) return true;
    const synRegex = new RegExp(`\\b${syn.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (synRegex.test(resumeTextLower)) return true;
  }

  return false;
}

// Match required & preferred skills against candidate resume
export function evaluateSkillMatches(
  candidateSkills: string[],
  resumeText: string,
  job: JobRequirement
): CandidateSkillMatch[] {
  const resumeLower = resumeText.toLowerCase();
  const results: CandidateSkillMatch[] = [];

  // Required skills (Core)
  job.requiredSkills.forEach(skill => {
    const matched = containsSkill(skill, candidateSkills, resumeLower);
    results.push({
      skill,
      matched,
      isCore: true,
      confidence: matched ? 100 : 0
    });
  });

  // Preferred skills (Bonus)
  job.preferredSkills.forEach(skill => {
    const matched = containsSkill(skill, candidateSkills, resumeLower);
    results.push({
      skill,
      matched,
      isCore: false,
      confidence: matched ? 90 : 0
    });
  });

  return results;
}

// Calculate Skill Score (0-100)
export function calculateSkillsScore(skillMatches: CandidateSkillMatch[]): number {
  const coreMatches = skillMatches.filter(m => m.isCore);
  const preferredMatches = skillMatches.filter(m => !m.isCore);

  const coreCount = coreMatches.length;
  const coreMatched = coreMatches.filter(m => m.matched).length;

  const prefCount = preferredMatches.length;
  const prefMatched = preferredMatches.filter(m => m.matched).length;

  if (coreCount === 0) return 100;

  // 80% weight on Core Skills, 20% weight on Preferred Skills
  const corePercentage = (coreMatched / coreCount) * 80;
  const prefPercentage = prefCount > 0 ? (prefMatched / prefCount) * 20 : 20;

  return Math.min(100, Math.round(corePercentage + prefPercentage));
}

// Calculate Experience Score (0-100)
export function calculateExperienceScore(yearsOfExp: number, minRequired: number, maxRequired?: number): number {
  if (yearsOfExp >= minRequired) {
    if (maxRequired && yearsOfExp > maxRequired + 5) {
      // Slightly overqualified (small decay)
      return 90;
    }
    return 100;
  } else {
    // Under minimum required experience
    const deficit = minRequired - yearsOfExp;
    const penalty = Math.min(60, deficit * 20);
    return Math.max(20, 100 - penalty);
  }
}

// Evaluate Education Score (0-100)
export function calculateEducationScore(resumeText: string, requiredEducation: string): number {
  const resumeLower = resumeText.toLowerCase();
  const reqLower = requiredEducation.toLowerCase();

  let score = 70; // baseline

  if (reqLower.includes('ph.d') || reqLower.includes('phd') || reqLower.includes('doctorate')) {
    if (resumeLower.includes('ph.d') || resumeLower.includes('phd') || resumeLower.includes('doctorate')) {
      score = 100;
    } else if (resumeLower.includes('master') || resumeLower.includes('m.s') || resumeLower.includes('mba')) {
      score = 80;
    } else {
      score = 50;
    }
  } else if (reqLower.includes('master') || reqLower.includes('m.s') || reqLower.includes('mba')) {
    if (resumeLower.includes('master') || resumeLower.includes('m.s') || resumeLower.includes('mba') || resumeLower.includes('ph.d')) {
      score = 100;
    } else if (resumeLower.includes('bachelor') || resumeLower.includes('b.s') || resumeLower.includes('b.a')) {
      score = 85;
    } else {
      score = 60;
    }
  } else if (reqLower.includes('bachelor') || reqLower.includes('b.s') || reqLower.includes('degree')) {
    if (resumeLower.includes('bachelor') || resumeLower.includes('b.s') || resumeLower.includes('b.a') || resumeLower.includes('master') || resumeLower.includes('ph.d')) {
      score = 100;
    } else {
      score = 70;
    }
  }

  return score;
}

// Detect Red Flags
export function detectRedFlags(
  yearsOfExp: number,
  job: JobRequirement,
  skillMatches: CandidateSkillMatch[]
): RedFlag[] {
  const flags: RedFlag[] = [];

  // Missing Core Mandatory Skills
  const missingCore = skillMatches.filter(m => m.isCore && !m.matched).map(m => m.skill);
  if (missingCore.length >= 2) {
    flags.push({
      type: 'missing_core',
      severity: missingCore.length >= 4 ? 'high' : 'medium',
      description: `Missing ${missingCore.length} core required skills: ${missingCore.slice(0, 3).join(', ')}${missingCore.length > 3 ? '...' : ''}`
    });
  }

  // Significant Experience Deficit
  if (yearsOfExp < job.minExperienceYears) {
    const deficit = job.minExperienceYears - yearsOfExp;
    flags.push({
      type: 'gap',
      severity: deficit >= 3 ? 'high' : 'medium',
      description: `Has ${yearsOfExp} years of experience vs ${job.minExperienceYears}+ years required (${deficit} years gap).`
    });
  }

  return flags;
}

// Full candidate evaluation engine
export function evaluateCandidate(
  input: SampleCandidateInput & { id?: string; fileFormat?: 'pdf' | 'docx' | 'txt' | 'sample'; appliedDate?: string },
  job: JobRequirement,
  weights: ScoringWeights = { skills: 0.4, experience: 0.3, education: 0.15, keywords: 0.15, shortlistThreshold: 75 }
): Candidate {
  const skillMatches = evaluateSkillMatches(input.skills, input.resumeText, job);
  const skillsScore = calculateSkillsScore(skillMatches);
  const experienceScore = calculateExperienceScore(input.yearsOfExperience, job.minExperienceYears, job.maxExperienceYears);
  const educationScore = calculateEducationScore(input.resumeText, job.requiredEducation);
  const keywordScore = computeCosineSimilarity(input.resumeText, job.description);

  // Compute Overall Weighted Fit Score
  const rawScore = (
    skillsScore * weights.skills +
    experienceScore * weights.experience +
    educationScore * weights.education +
    keywordScore * weights.keywords
  );

  const overallScore = Math.min(100, Math.max(0, Math.round(rawScore)));

  // Determine Shortlist Status
  let status: CandidateEvaluation['status'] = 'Unsuitable';
  if (overallScore >= weights.shortlistThreshold) {
    status = overallScore >= 88 ? 'Top Shortlist' : 'Strong Match';
  } else if (overallScore >= 60) {
    status = 'Potential Match';
  }

  const redFlags = detectRedFlags(input.yearsOfExperience, job, skillMatches);

  // Identify Strengths and Gaps
  const matchedCoreSkills = skillMatches.filter(m => m.isCore && m.matched).map(m => m.skill);
  const matchedPrefSkills = skillMatches.filter(m => !m.isCore && m.matched).map(m => m.skill);
  const missingCoreSkills = skillMatches.filter(m => m.isCore && !m.matched).map(m => m.skill);

  const strengths: string[] = [];
  if (matchedCoreSkills.length > 0) {
    strengths.push(`Strong core skill coverage: ${matchedCoreSkills.join(', ')}`);
  }
  if (input.yearsOfExperience >= job.minExperienceYears) {
    strengths.push(`Meets experience requirement (${input.yearsOfExperience} YOE vs ${job.minExperienceYears} min)`);
  }
  if (matchedPrefSkills.length > 0) {
    strengths.push(`Possesses preferred skills: ${matchedPrefSkills.join(', ')}`);
  }

  const gaps: string[] = [];
  if (missingCoreSkills.length > 0) {
    gaps.push(`Lacks required skills: ${missingCoreSkills.join(', ')}`);
  }
  if (input.yearsOfExperience < job.minExperienceYears) {
    gaps.push(`Under required experience (${input.yearsOfExperience} YOE vs ${job.minExperienceYears} min)`);
  }

  // Executive Summary text
  const executiveSummary = `${input.name} achieves a ${overallScore}% overall match for ${job.title}. ${
    status === 'Top Shortlist'
      ? 'Highly recommended candidate demonstrating strong alignment with core tech stack and experience requirements.'
      : status === 'Strong Match'
      ? 'Solid candidate meeting most critical requirements with good domain experience.'
      : status === 'Potential Match'
      ? 'Meets some prerequisites but has notable skill or experience gaps worth reviewing.'
      : 'Does not meet minimum requirements for this position.'
  }`;

  // Suggested interview questions
  const suggestedInterviewQuestions: string[] = [
    `Can you describe your experience implementing ${matchedCoreSkills[0] || 'core project tech'} in production?`,
  ];
  if (missingCoreSkills.length > 0) {
    suggestedInterviewQuestions.push(`How quickly can you get up to speed with ${missingCoreSkills[0]}?`);
  }
  suggestedInterviewQuestions.push(`Walk us through a major technical challenge you faced at your previous role.`);

  const scores: ScoreBreakdown = {
    skillsScore,
    experienceScore,
    educationScore,
    keywordScore,
    overallScore
  };

  const evaluation: CandidateEvaluation = {
    status,
    executiveSummary,
    strengths,
    gaps,
    redFlags,
    suggestedInterviewQuestions
  };

  return {
    id: input.id || `candidate-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    name: input.name,
    email: input.email,
    phone: input.phone,
    location: input.location,
    currentRole: input.currentRole,
    yearsOfExperience: input.yearsOfExperience,
    education: input.education,
    skills: input.skills,
    resumeText: input.resumeText,
    fileFormat: input.fileFormat || 'sample',
    appliedDate: input.appliedDate || new Date().toISOString().split('T')[0],
    scores,
    skillMatches,
    evaluation,
    shortlisted: overallScore >= weights.shortlistThreshold
  };
}
