import { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { ResumeUploader } from './components/ResumeUploader';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { JobRequirementForm } from './components/JobRequirementForm';
import { CandidateDetailModal } from './components/CandidateDetailModal';
import { CandidateComparison } from './components/CandidateComparison';
import { WeightingSettings } from './components/WeightingSettings';
import { EmailGeneratorModal } from './components/EmailGeneratorModal';

import type { Candidate, JobRequirement, ScoringWeights } from './types/resume';
import type { SampleCandidateInput } from './utils/mockData';
import { MOCK_JOBS, DEFAULT_WEIGHTS, SAMPLE_CANDIDATES_RAW } from './utils/mockData';
import { evaluateCandidate } from './utils/nlpEngine';
import { exportCandidatesToCSV } from './utils/exportUtils';
import { Key, X, Check, Sparkles } from 'lucide-react';

export function App() {
  // Active Jobs state
  const [jobs, setJobs] = useState<JobRequirement[]>(MOCK_JOBS);
  const [activeJob, setActiveJob] = useState<JobRequirement>(MOCK_JOBS[0]);

  // HR Scoring Weights state
  const [weights, setWeights] = useState<ScoringWeights>(DEFAULT_WEIGHTS);

  // Gemini API Key state
  const [geminiApiKey, setGeminiApiKey] = useState<string>('');
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState<boolean>(false);
  const [tempApiKeyInput, setTempApiKeyInput] = useState<string>('');

  // Candidates state
  const [rawCandidatesInput, setRawCandidatesInput] = useState<SampleCandidateInput[]>(SAMPLE_CANDIDATES_RAW);

  // Navigation tab: 'candidates' | 'analytics'
  const [activeTab, setActiveTab] = useState<'candidates' | 'analytics' | 'comparison'>('candidates');

  // Modals state
  const [isJobFormOpen, setIsJobFormOpen] = useState(false);
  const [isWeightsModalOpen, setIsWeightsModalOpen] = useState(false);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);

  const [selectedCandidateDetail, setSelectedCandidateDetail] = useState<Candidate | null>(null);
  const [selectedCandidateEmail, setSelectedCandidateEmail] = useState<Candidate | null>(null);

  const [comparedIds, setComparedIds] = useState<string[]>([]);

  // Evaluate candidates against active job & current weights
  const candidates: Candidate[] = useMemo(() => {
    return rawCandidatesInput.map((input, idx) => {
      const candidateId = `cand-${idx}-${input.name.toLowerCase().replace(/\s+/g, '-')}`;
      return evaluateCandidate({ ...input, id: candidateId }, activeJob, weights);
    });
  }, [rawCandidatesInput, activeJob, weights]);

  // Compared candidates list
  const comparedCandidates = useMemo(() => {
    return candidates.filter(c => comparedIds.includes(c.id));
  }, [candidates, comparedIds]);

  // Handlers
  const handleAddCandidates = (newInputs: SampleCandidateInput[]) => {
    setRawCandidatesInput(prev => [...newInputs, ...prev]);
  };

  const handleLoadSamples = () => {
    setRawCandidatesInput(SAMPLE_CANDIDATES_RAW);
  };

  const handleSaveJob = (updatedJob: JobRequirement) => {
    setJobs(prev => {
      const exists = prev.some(j => j.id === updatedJob.id);
      if (exists) {
        return prev.map(j => (j.id === updatedJob.id ? updatedJob : j));
      }
      return [updatedJob, ...prev];
    });
    setActiveJob(updatedJob);
  };

  const handleToggleCompare = (candidate: Candidate) => {
    setComparedIds(prev => {
      if (prev.includes(candidate.id)) {
        return prev.filter(id => id !== candidate.id);
      }
      if (prev.length >= 4) {
        alert('You can compare up to 4 candidates side-by-side.');
        return prev;
      }
      return [...prev, candidate.id];
    });
  };

  const handleSaveApiKey = () => {
    setGeminiApiKey(tempApiKeyInput.trim());
    setIsApiKeyModalOpen(false);
  };

  const handleExportCSV = () => {
    exportCandidatesToCSV(candidates, activeJob);
  };

  const handleUpdateCandidateEval = (_candidateId: string, updatedEval: any) => {
    // Allows updating Gemini deep qualitative analysis
    setSelectedCandidateDetail(prev => prev ? { ...prev, evaluation: updatedEval } : null);
  };

  const shortlistedCount = candidates.filter(c => c.shortlisted).length;

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 font-sans selection:bg-blue-500 selection:text-white pb-16">
      
      {/* Top Navbar */}
      <Navbar
        jobs={jobs}
        activeJob={activeJob}
        onSelectJob={setActiveJob}
        onOpenJobForm={() => setIsJobFormOpen(true)}
        onOpenWeightsModal={() => setIsWeightsModalOpen(true)}
        onOpenApiKeyModal={() => {
          setTempApiKeyInput(geminiApiKey);
          setIsApiKeyModalOpen(true);
        }}
        onOpenComparison={() => setIsComparisonOpen(true)}
        onExportCSV={handleExportCSV}
        hasGeminiKey={Boolean(geminiApiKey)}
        totalCandidates={candidates.length}
        shortlistedCount={shortlistedCount}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        
        {/* Bulk Resume Uploader */}
        <ResumeUploader
          onAddCandidates={handleAddCandidates}
          onLoadSamples={handleLoadSamples}
        />

        {/* Tab View Switcher */}
        {activeTab === 'candidates' && (
          <Dashboard
            job={activeJob}
            candidates={candidates}
            onSelectCandidate={setSelectedCandidateDetail}
            onToggleCompare={handleToggleCompare}
            comparedIds={comparedIds}
            onOpenEmail={setSelectedCandidateEmail}
            onOpenJobForm={() => setIsJobFormOpen(true)}
            onOpenWeightsModal={() => setIsWeightsModalOpen(true)}
            shortlistCutoff={weights.shortlistThreshold}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsCharts
            candidates={candidates}
            job={activeJob}
          />
        )}

      </main>

      {/* Floating Side-by-Side Comparison Pill (if candidates selected) */}
      {comparedIds.length > 0 && (
        <div className="fixed bottom-6 right-6 z-40">
          <button
            onClick={() => setIsComparisonOpen(true)}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-2xl shadow-amber-500/30 transition transform hover:scale-105"
          >
            <Sparkles className="h-4 w-4" />
            <span>Compare {comparedIds.length} Candidates Side-by-Side</span>
          </button>
        </div>
      )}

      {/* MODALS */}

      {/* Job Requirement Builder Modal */}
      {isJobFormOpen && (
        <JobRequirementForm
          activeJob={activeJob}
          onSaveJob={handleSaveJob}
          onClose={() => setIsJobFormOpen(false)}
        />
      )}

      {/* HR Weights Settings Modal */}
      {isWeightsModalOpen && (
        <WeightingSettings
          weights={weights}
          onSaveWeights={setWeights}
          onClose={() => setIsWeightsModalOpen(false)}
        />
      )}

      {/* Candidate Deep-Dive Detail Modal */}
      {selectedCandidateDetail && (
        <CandidateDetailModal
          candidate={selectedCandidateDetail}
          job={activeJob}
          onClose={() => setSelectedCandidateDetail(null)}
          onOpenEmail={(c) => {
            setSelectedCandidateDetail(null);
            setSelectedCandidateEmail(c);
          }}
          geminiApiKey={geminiApiKey}
          onUpdateCandidateEvaluation={handleUpdateCandidateEval}
        />
      )}

      {/* Candidate Comparison Modal */}
      {isComparisonOpen && (
        <CandidateComparison
          candidates={comparedCandidates}
          job={activeJob}
          onRemoveFromCompare={(id) => setComparedIds(prev => prev.filter(i => i !== id))}
          onClose={() => setIsComparisonOpen(false)}
          onOpenEmail={(c) => {
            setIsComparisonOpen(false);
            setSelectedCandidateEmail(c);
          }}
        />
      )}

      {/* Candidate Email Outreach Generator Modal */}
      {selectedCandidateEmail && (
        <EmailGeneratorModal
          candidate={selectedCandidateEmail}
          job={activeJob}
          onClose={() => setSelectedCandidateEmail(null)}
        />
      )}

      {/* Gemini API Key Configuration Modal */}
      {isApiKeyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="glass-panel w-full max-w-md rounded-2xl p-6 shadow-2xl border border-slate-800 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <Key className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Google Gemini API Key</h3>
                  <p className="text-xs text-slate-400">Enable deep qualitative AI resume evaluation</p>
                </div>
              </div>
              <button onClick={() => setIsApiKeyModalOpen(false)} className="p-1 rounded-lg text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-300">
              <p>
                Enter your Google Gemini API key below to unlock LLM qualitative summaries, custom strengths/gaps analysis, and interview questions.
              </p>
              <div>
                <label className="block font-medium text-slate-300 mb-1">Gemini API Key</label>
                <input
                  type="password"
                  value={tempApiKeyInput}
                  onChange={e => setTempApiKeyInput(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/20 text-[11px] text-blue-300">
                💡 <em>If no key is provided, RecruitAI automatically uses its high-accuracy local NLP engine.</em>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  onClick={() => setIsApiKeyModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveApiKey}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl flex items-center gap-1.5"
                >
                  <Check className="h-4 w-4" /> Save API Key
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
