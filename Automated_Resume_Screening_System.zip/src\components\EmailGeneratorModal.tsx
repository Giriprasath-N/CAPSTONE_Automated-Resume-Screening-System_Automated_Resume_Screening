import React, { useState } from 'react';
import { X, Mail, Copy, Check, Sparkles } from 'lucide-react';
import type { Candidate, JobRequirement } from '../types/resume';

interface EmailGeneratorModalProps {
  candidate: Candidate;
  job: JobRequirement;
  onClose: () => void;
}

export const EmailGeneratorModal: React.FC<EmailGeneratorModalProps> = ({
  candidate,
  job,
  onClose
}) => {
  const [emailType, setEmailType] = useState<'interview' | 'rejection'>('interview');
  const [copied, setCopied] = useState(false);

  const matchedSkills = candidate.skillMatches.filter(m => m.matched).map(m => m.skill).slice(0, 3).join(', ');

  const generateEmailText = () => {
    if (emailType === 'interview') {
      return `Subject: Interview Invitation: ${job.title} Role at RecruitAI Talent Team

Dear ${candidate.name},

Thank you for applying for the ${job.title} position at our company.

Our HR Talent Acquisition team reviewed your resume and was thoroughly impressed by your background, particularly your strong experience with ${matchedSkills || 'core technical skills'} and your ${candidate.yearsOfExperience} years of domain expertise.

We would love to invite you for an initial 30-minute screening call with our engineering team to discuss your background and learn more about your career goals.

Please let us know your availability over the next few days or pick a convenient time on our scheduling calendar: https://calendly.com/recruit-ai/interview-screening

Looking forward to connecting!

Best regards,

Talent Acquisition Team
RecruitAI Enterprise Solutions`;
    } else {
      return `Subject: Update regarding your application for ${job.title}

Dear ${candidate.name},

Thank you for taking the time to apply for the ${job.title} role and for sharing your background with us.

After carefully reviewing your application against our current target requirements, we have decided to move forward with candidates whose experience and specific skills more closely align with our immediate needs for this position.

We were impressed by your profile and will keep your resume on file for future opportunities that match your qualifications.

We wish you the very best in your job search and future professional endeavors.

Sincerely,

Talent Acquisition Team
RecruitAI Enterprise Solutions`;
    }
  };

  const emailText = generateEmailText();

  const handleCopy = () => {
    navigator.clipboard.writeText(emailText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="glass-panel w-full max-w-xl rounded-2xl p-6 shadow-2xl border border-slate-800 animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Automated Candidate Outreach</h2>
              <p className="text-xs text-slate-400">Generate personalized email for {candidate.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Email Type Toggle */}
        <div className="flex gap-2 mb-4 p-1 bg-slate-900/90 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setEmailType('interview')}
            className={`flex-1 py-2 rounded-lg font-semibold transition ${
              emailType === 'interview'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ✓ Interview Invitation
          </button>
          <button
            onClick={() => setEmailType('rejection')}
            className={`flex-1 py-2 rounded-lg font-semibold transition ${
              emailType === 'rejection'
                ? 'bg-slate-700 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ✗ Polite Rejection
          </button>
        </div>

        {/* Email Preview Container */}
        <div className="relative mb-5">
          <textarea
            readOnly
            rows={12}
            value={emailText}
            className="w-full p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 font-sans leading-relaxed resize-none focus:outline-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <Sparkles className="h-3.5 w-3.5 text-blue-400" />
            Recipient: <strong className="text-slate-200">{candidate.email}</strong>
          </span>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleCopy}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-blue-600/20"
            >
              {copied ? <Check className="h-4 w-4 text-emerald-300" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Email Text'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
