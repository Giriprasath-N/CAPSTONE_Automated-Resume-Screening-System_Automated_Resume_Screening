import React, { useState, useRef } from 'react';
import { UploadCloud, Sparkles, Loader2 } from 'lucide-react';
import { parseDocxFile, parsePdfFile, parseTxtFile, extractCandidateMetadataFromText } from '../utils/fileParsers';
import type { SampleCandidateInput } from '../utils/mockData';
import { SAMPLE_CANDIDATES_RAW } from '../utils/mockData';

interface ResumeUploaderProps {
  onAddCandidates: (candidates: SampleCandidateInput[]) => void;
  onLoadSamples: () => void;
}

export const ResumeUploader: React.FC<ResumeUploaderProps> = ({
  onAddCandidates,
  onLoadSamples
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedCount, setProcessedCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFiles = async (files: FileList | File[]) => {
    setIsProcessing(true);
    setProcessedCount(0);
    const parsedCandidates: SampleCandidateInput[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const ext = file.name.split('.').pop()?.toLowerCase();
      let rawText = '';

      try {
        if (ext === 'pdf') {
          rawText = await parsePdfFile(file);
        } else if (ext === 'docx') {
          rawText = await parseDocxFile(file);
        } else if (ext === 'txt') {
          rawText = await parseTxtFile(file);
        } else {
          console.warn(`Unsupported file format: ${file.name}`);
          continue;
        }

        if (rawText.trim()) {
          const candidateMeta = extractCandidateMetadataFromText(file.name, rawText);
          parsedCandidates.push(candidateMeta);
        }
      } catch (err) {
        console.error(`Error parsing file ${file.name}:`, err);
      }
      setProcessedCount(i + 1);
    }

    if (parsedCandidates.length > 0) {
      onAddCandidates(parsedCandidates);
    }

    setIsProcessing(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-5 border border-slate-800 shadow-xl mb-6">
      <div className="flex flex-col lg:flex-row items-center gap-5 justify-between">
        
        {/* Upload Zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`flex-1 w-full p-5 rounded-xl border-2 border-dashed transition flex items-center justify-center cursor-pointer ${
            isDragging
              ? 'border-blue-500 bg-blue-500/10 scale-[1.01]'
              : 'border-slate-700/80 bg-slate-900/60 hover:border-blue-500/50 hover:bg-slate-900/90'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.docx,.txt"
            onChange={handleFileSelect}
            className="hidden"
          />

          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
            <div className="h-12 w-12 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20 shrink-0">
              {isProcessing ? (
                <Loader2 className="h-6 w-6 animate-spin" />
              ) : (
                <UploadCloud className="h-6 w-6" />
              )}
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-100 flex items-center justify-center sm:justify-start gap-2">
                <span>Upload Candidate Resumes</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  PDF, DOCX, TXT
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Drag & drop files or click to browse. Bulk parsing enabled.
              </p>
              {isProcessing && (
                <p className="text-xs text-blue-400 font-medium mt-1 animate-pulse">
                  Parsing and evaluating resume {processedCount}...
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="hidden lg:flex items-center justify-center text-xs font-semibold text-slate-500 uppercase tracking-widest px-2">
          OR
        </div>

        {/* One-Click Sample Pool Loader */}
        <div className="w-full lg:w-auto shrink-0 flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={onLoadSamples}
            className="w-full sm:w-auto px-5 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 transition hover:scale-[1.02]"
          >
            <Sparkles className="h-4 w-4 text-amber-300" />
            <span>Load Sample Candidate Pool ({SAMPLE_CANDIDATES_RAW.length} Resumes)</span>
          </button>
        </div>

      </div>
    </div>
  );
};
