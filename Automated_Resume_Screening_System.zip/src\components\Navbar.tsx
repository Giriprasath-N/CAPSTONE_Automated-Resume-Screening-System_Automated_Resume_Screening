import React from 'react';
import {
  Brain,
  SlidersHorizontal,
  Key,
  Briefcase,
  Users,
  Download,
  PlusCircle,
  BarChart3
} from 'lucide-react';
import type { JobRequirement } from '../types/resume';

interface NavbarProps {
  jobs: JobRequirement[];
  activeJob: JobRequirement;
  onSelectJob: (job: JobRequirement) => void;
  onOpenJobForm: () => void;
  onOpenWeightsModal: () => void;
  onOpenApiKeyModal: () => void;
  onOpenComparison: () => void;
  onExportCSV: () => void;
  hasGeminiKey: boolean;
  totalCandidates: number;
  shortlistedCount: number;
  activeTab: 'candidates' | 'analytics' | 'comparison';
  setActiveTab: (tab: 'candidates' | 'analytics' | 'comparison') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  jobs,
  activeJob,
  onSelectJob,
  onOpenJobForm,
  onOpenWeightsModal,
  onOpenApiKeyModal,
  onExportCSV,
  hasGeminiKey,
  totalCandidates,
  activeTab,
  setActiveTab
}) => {
  return (
    <header className="sticky top-0 z-40 glass-panel border-b border-slate-800 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20 ring-1 ring-white/20">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-white tracking-wide">Recruit<span className="text-blue-400">AI</span></span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  NLP Screening Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">AI Candidate Shortlisting & Resume Analytics</p>
            </div>
          </div>

          {/* Active Job Selector */}
          <div className="flex-1 max-w-xs hidden md:block">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Briefcase className="h-4 w-4 text-blue-400" />
              </div>
              <select
                value={activeJob.id}
                onChange={(e) => {
                  const selected = jobs.find(j => j.id === e.target.value);
                  if (selected) onSelectJob(selected);
                }}
                className="w-full pl-9 pr-8 py-1.5 text-xs bg-slate-900/90 border border-slate-700/80 rounded-lg text-slate-200 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 hover:border-slate-600 transition"
              >
                {jobs.map(j => (
                  <option key={j.id} value={j.id}>
                    {j.title} ({j.department})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center bg-slate-900/80 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('candidates')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'candidates'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="h-3.5 w-3.5" />
              <span>Candidates ({totalCandidates})</span>
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'analytics'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BarChart3 className="h-3.5 w-3.5" />
              <span>Analytics</span>
            </button>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenJobForm}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700/60 transition"
              title="Job Description Builder"
            >
              <PlusCircle className="h-3.5 w-3.5 text-blue-400" />
              <span className="hidden lg:inline">Edit Job Profile</span>
            </button>

            <button
              onClick={onOpenWeightsModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700/60 transition"
              title="Customize HR Weightings"
            >
              <SlidersHorizontal className="h-3.5 w-3.5 text-amber-400" />
              <span className="hidden lg:inline">HR Weights</span>
            </button>

            <button
              onClick={onOpenApiKeyModal}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition ${
                hasGeminiKey
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
              title="Configure Gemini LLM Key"
            >
              <Key className="h-3.5 w-3.5" />
              <span className="hidden lg:inline">{hasGeminiKey ? 'Gemini Active' : 'Gemini Key'}</span>
            </button>

            <button
              onClick={onExportCSV}
              disabled={totalCandidates === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/20 disabled:opacity-50 transition"
            >
              <Download className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Export Shortlist</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
