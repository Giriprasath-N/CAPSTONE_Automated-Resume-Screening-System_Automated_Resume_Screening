import React, { useState } from 'react';
import { X, Briefcase, Plus, Tag, Check, Sparkles } from 'lucide-react';
import type { JobRequirement } from '../types/resume';
import { MOCK_JOBS } from '../utils/mockData';

interface JobRequirementFormProps {
  activeJob: JobRequirement;
  onSaveJob: (job: JobRequirement) => void;
  onClose: () => void;
}

export const JobRequirementForm: React.FC<JobRequirementFormProps> = ({
  activeJob,
  onSaveJob,
  onClose
}) => {
  const [formData, setFormData] = useState<JobRequirement>({ ...activeJob });
  const [reqSkillInput, setReqSkillInput] = useState('');
  const [prefSkillInput, setPrefSkillInput] = useState('');

  const handleAddReqSkill = () => {
    if (reqSkillInput.trim() && !formData.requiredSkills.includes(reqSkillInput.trim())) {
      setFormData(prev => ({
        ...prev,
        requiredSkills: [...prev.requiredSkills, reqSkillInput.trim()]
      }));
      setReqSkillInput('');
    }
  };

  const handleRemoveReqSkill = (skill: string) => {
    setFormData(prev => ({
      ...prev,
      requiredSkills: prev.requiredSkills.filter(s => s !== skill)
    }));
  };

  const handleAddPrefSkill = () => {
    if (prefSkillInput.trim() && !formData.preferredSkills.includes(prefSkillInput.trim())) {
      setFormData(prev => ({
        ...prev,
        preferredSkills: [...prev.preferredSkills, prefSkillInput.trim()]
      }));
      setPrefSkillInput('');
    }
  };

  const handleRemovePrefSkill = (skill: string) => {
    setFormData(prev => ({
      ...prev,
      preferredSkills: prev.preferredSkills.filter(s => s !== skill)
    }));
  };

  const handleLoadTemplate = (jobId: string) => {
    const template = MOCK_JOBS.find(j => j.id === jobId);
    if (template) {
      setFormData({ ...template, id: `job-${Date.now()}` });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveJob(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="glass-panel w-full max-w-3xl rounded-2xl max-h-[90vh] flex flex-col shadow-2xl border border-slate-800 animate-in fade-in zoom-in duration-200">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Briefcase className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Job Requirement Builder</h2>
              <p className="text-xs text-slate-400">Configure target job specifications for NLP screening</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 text-slate-200 text-xs">
          
          {/* Quick Template Selector */}
          <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-blue-400 shrink-0" />
              <span className="font-semibold text-slate-200">Load Preset Template:</span>
            </div>
            <div className="flex gap-2 flex-wrap">
              {MOCK_JOBS.map(job => (
                <button
                  key={job.id}
                  type="button"
                  onClick={() => handleLoadTemplate(job.id)}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 text-[11px] font-medium border border-slate-700 transition"
                >
                  {job.title}
                </button>
              ))}
            </div>
          </div>

          {/* Job Title & Department */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-medium text-slate-300 mb-1">Job Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. Senior Full Stack Engineer"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-300 mb-1">Department *</label>
              <input
                type="text"
                required
                value={formData.department}
                onChange={e => setFormData({ ...formData, department: e.target.value })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. Engineering, Product, Data Science"
              />
            </div>
          </div>

          {/* Location & Employment Type & Experience */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-medium text-slate-300 mb-1">Location</label>
              <input
                type="text"
                value={formData.location}
                onChange={e => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. San Francisco, CA / Remote"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-300 mb-1">Employment Type</label>
              <select
                value={formData.employmentType}
                onChange={e => setFormData({ ...formData, employmentType: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Full-Time">Full-Time</option>
                <option value="Part-Time">Part-Time</option>
                <option value="Contract">Contract</option>
                <option value="Remote">Remote</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-300 mb-1">Min Required Experience (Years)</label>
              <input
                type="number"
                min={0}
                max={20}
                value={formData.minExperienceYears}
                onChange={e => setFormData({ ...formData, minExperienceYears: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Mandatory Required Core Skills Tag Input */}
          <div>
            <label className="block font-medium text-slate-300 mb-1">
              Required Core Skills <span className="text-red-400">*</span> (Mandatory for High Score)
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={reqSkillInput}
                onChange={e => setReqSkillInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); handleAddReqSkill(); } }}
                placeholder="Type skill and press Enter (e.g. React, Python)"
                className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={handleAddReqSkill}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium flex items-center gap-1"
              >
                <Plus className="h-4 w-4" /> Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 min-h-[32px] p-2 bg-slate-950/60 rounded-lg border border-slate-800">
              {formData.requiredSkills.map(skill => (
                <span
                  key={skill}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30"
                >
                  <Tag className="h-3 w-3" /> {skill}
                  <button
                    type="button"
                    onClick={() => handleRemoveReqSkill(skill)}
                    className="hover:text-red-400 ml-1"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Preferred Skills Tag Input */}
          <div>
            <label className="block font-medium text-slate-300 mb-1">
              Preferred / Nice-to-Have Skills (Bonus Weight)
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={prefSkillInput}
                onChange={e => setPrefSkillInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); handleAddPrefSkill(); } }}
                placeholder="Type preferred skill and press Enter (e.g. Docker, AWS)"
                className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={handleAddPrefSkill}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium flex items-center gap-1"
              >
                <Plus className="h-4 w-4" /> Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 min-h-[32px] p-2 bg-slate-950/60 rounded-lg border border-slate-800">
              {formData.preferredSkills.map(skill => (
                <span
                  key={skill}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30"
                >
                  <Tag className="h-3 w-3" /> {skill}
                  <button
                    type="button"
                    onClick={() => handleRemovePrefSkill(skill)}
                    className="hover:text-red-400 ml-1"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Education Requirement */}
          <div>
            <label className="block font-medium text-slate-300 mb-1">Required Education Level</label>
            <input
              type="text"
              value={formData.requiredEducation}
              onChange={e => setFormData({ ...formData, requiredEducation: e.target.value })}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g. Bachelor's in Computer Science, Software Engineering, or related field"
            />
          </div>

          {/* Full Job Description */}
          <div>
            <label className="block font-medium text-slate-300 mb-1">Full Job Description Text (For TF-IDF & LLM Cosine Matching)</label>
            <textarea
              rows={5}
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Paste full job description text here..."
            />
          </div>

          {/* Footer Save Button */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold rounded-xl flex items-center gap-2 shadow-lg shadow-blue-600/25"
            >
              <Check className="h-4 w-4" /> Save Job Specification
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
