import React from 'react';
import { X, Scale, Trash2 } from 'lucide-react';
import type { Candidate, JobRequirement } from '../types/resume';

interface CandidateComparisonProps {
  candidates: Candidate[];
  job: JobRequirement;
  onRemoveFromCompare: (candidateId: string) => void;
  onClose: () => void;
  onOpenEmail: (candidate: Candidate) => void;
}

export const CandidateComparison: React.FC<CandidateComparisonProps> = ({
  candidates,
  job,
  onRemoveFromCompare,
  onClose,
  onOpenEmail
}) => {
  if (candidates.length === 0) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
        <div className="glass-panel w-full max-w-md rounded-2xl p-6 text-center border border-slate-800">
          <Scale className="h-12 w-12 text-amber-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-2">No Candidates Selected for Comparison</h3>
          <p className="text-xs text-slate-400 mb-5">
            Click the <Scale className="h-3.5 w-3.5 inline text-amber-400" /> icon on candidate cards to select up to 4 candidates for side-by-side evaluation.
          </p>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold"
          >
            Close & Select Candidates
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="glass-panel w-full max-w-6xl rounded-2xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-800">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Scale className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Side-by-Side Candidate Matrix</h2>
              <p className="text-xs text-slate-400">Comparing {candidates.length} candidates for {job.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Matrix Grid Container */}
        <div className="p-6 overflow-x-auto overflow-y-auto flex-1">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="p-3 w-48 text-slate-400 font-bold uppercase tracking-wider bg-slate-900/60 rounded-tl-xl">
                  Criterion
                </th>
                {candidates.map(c => (
                  <th key={c.id} className="p-4 min-w-[240px] bg-slate-900/90 border-l border-slate-800 align-top">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <h4 className="font-bold text-slate-100 text-sm">{c.name}</h4>
                        <p className="text-[11px] text-slate-400">{c.currentRole}</p>
                      </div>
                      <button
                        onClick={() => onRemoveFromCompare(c.id)}
                        className="text-slate-500 hover:text-rose-400 p-1"
                        title="Remove"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 font-semibold border border-blue-500/20">
                        {c.evaluation.status}
                      </span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-800/80">
              
              {/* Overall Score */}
              <tr>
                <td className="p-3 font-semibold text-slate-300 bg-slate-950/40">Overall Match Score</td>
                {candidates.map(c => (
                  <td key={c.id} className="p-4 border-l border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <div className="h-10 w-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center font-bold text-blue-300 text-sm">
                        {c.scores.overallScore}%
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-blue-500 to-emerald-400 h-full rounded-full"
                          style={{ width: `${c.scores.overallScore}%` }}
                        />
                      </div>
                    </div>
                  </td>
                ))}
              </tr>

              {/* Experience */}
              <tr>
                <td className="p-3 font-semibold text-slate-300 bg-slate-950/40">Years of Experience</td>
                {candidates.map(c => (
                  <td key={c.id} className="p-4 border-l border-slate-800/80">
                    <span className="font-bold text-slate-200">{c.yearsOfExperience} Years</span>
                    <span className="text-slate-500 ml-1.5">(Req: {job.minExperienceYears}+ yrs)</span>
                  </td>
                ))}
              </tr>

              {/* Education */}
              <tr>
                <td className="p-3 font-semibold text-slate-300 bg-slate-950/40">Education</td>
                {candidates.map(c => (
                  <td key={c.id} className="p-4 border-l border-slate-800/80 text-slate-300">
                    {c.education}
                  </td>
                ))}
              </tr>

              {/* Core Skill Coverage */}
              <tr>
                <td className="p-3 font-semibold text-slate-300 bg-slate-950/40">Core Skills Coverage</td>
                {candidates.map(c => {
                  const matchedCore = c.skillMatches.filter(m => m.isCore && m.matched);
                  const missingCore = c.skillMatches.filter(m => m.isCore && !m.matched);
                  return (
                    <td key={c.id} className="p-4 border-l border-slate-800/80 space-y-2">
                      <div>
                        <div className="text-[10px] font-bold text-emerald-400 uppercase mb-1">
                          Matched ({matchedCore.length}/{job.requiredSkills.length})
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {matchedCore.map(m => (
                            <span key={m.skill} className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 text-[10px] font-medium border border-emerald-500/20">
                              ✓ {m.skill}
                            </span>
                          ))}
                        </div>
                      </div>

                      {missingCore.length > 0 && (
                        <div>
                          <div className="text-[10px] font-bold text-rose-400 uppercase mb-1">Missing</div>
                          <div className="flex flex-wrap gap-1">
                            {missingCore.map(m => (
                              <span key={m.skill} className="px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-300 text-[10px] font-medium border border-rose-500/20">
                                ✗ {m.skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>

              {/* Key Strengths */}
              <tr>
                <td className="p-3 font-semibold text-slate-300 bg-slate-950/40">Key Strengths</td>
                {candidates.map(c => (
                  <td key={c.id} className="p-4 border-l border-slate-800/80">
                    <ul className="space-y-1 text-slate-300 text-[11px]">
                      {c.evaluation.strengths.slice(0, 3).map((st, idx) => (
                        <li key={idx} className="flex items-start gap-1">
                          <span className="text-emerald-400 font-bold">•</span> {st}
                        </li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>

              {/* Action Buttons */}
              <tr>
                <td className="p-3 font-semibold text-slate-300 bg-slate-950/40">Action</td>
                {candidates.map(c => (
                  <td key={c.id} className="p-4 border-l border-slate-800/80">
                    <button
                      onClick={() => onOpenEmail(c)}
                      className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5"
                    >
                      Contact {c.name.split(' ')[0]}
                    </button>
                  </td>
                ))}
              </tr>

            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};
