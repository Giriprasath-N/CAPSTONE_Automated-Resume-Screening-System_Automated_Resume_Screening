import type { CandidateEvaluation, JobRequirement } from '../types/resume';

export async function analyzeResumeWithGemini(
  resumeText: string,
  job: JobRequirement,
  apiKey: string
): Promise<Partial<CandidateEvaluation> | null> {
  if (!apiKey) return null;

  const prompt = `You are an expert HR Talent Acquisition Specialist. Analyze the following candidate resume against the Job Requirement.

Job Title: ${job.title}
Department: ${job.department}
Required Experience: ${job.minExperienceYears}+ years
Required Skills: ${job.requiredSkills.join(', ')}
Preferred Skills: ${job.preferredSkills.join(', ')}
Required Education: ${job.requiredEducation}
Job Description Summary:
${job.description}

Candidate Resume Text:
"""
${resumeText}
"""

Provide your assessment strictly in the following JSON format:
{
  "executiveSummary": "2-3 sentences executive summary for HR recruiters",
  "strengths": ["Strength 1", "Strength 2", "Strength 3"],
  "gaps": ["Gap 1", "Gap 2"],
  "suggestedInterviewQuestions": [
    "Technical question 1 related to resume experience",
    "Domain question 2",
    "Culture/Skill question 3"
  ]
}`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            responseMimeType: 'application/json',
            temperature: 0.2
          }
        })
      }
    );

    if (!response.ok) {
      console.warn('Gemini API call failed:', response.statusText);
      return null;
    }

    const data = await response.json();
    const resultText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!resultText) return null;

    const parsed = JSON.parse(resultText);
    return {
      executiveSummary: parsed.executiveSummary,
      strengths: parsed.strengths || [],
      gaps: parsed.gaps || [],
      suggestedInterviewQuestions: parsed.suggestedInterviewQuestions || []
    };
  } catch (error) {
    console.error('Error invoking Gemini API:', error);
    return null;
  }
}
