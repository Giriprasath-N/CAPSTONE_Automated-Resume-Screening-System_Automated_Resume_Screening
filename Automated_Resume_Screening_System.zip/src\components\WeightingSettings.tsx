import React, { useState } from 'react';
import { X, SlidersHorizontal, Check, RefreshCw } from 'lucide-react';
import type { ScoringWeights } from '../types/resume';

interface WeightingSettingsProps {
  weights: ScoringWeights;
  onSaveWeights: (newWeights: ScoringWeights) => void;
  onClose: () => void;
}

export const WeightingSettings: React.FC<WeightingSettingsProps> = ({
  weights,
  onSaveWeights,
  onClose
}) => {
  const [skills, setSkills] = useState(Math.round(weights.skills * 100));
  const [experience, setExperience] = useState(Math.round(weights.experience * 100));
  const [education, setEducation] = useState(Math.round(weights.education * 100));
  const [keywords, setKeywords] = useState(Math.round(weights.keywords * 100));
  const [threshold, setThreshold] = useState(weights.shortlistThreshold);

  const totalWeight = skills + experience + education + keywords;

  const handleSave = () => {
    if (totalWeight === 0) return;
    // Normalize to sum to 1.0
    const factor = 100 / totalWeight;
    const newWeights: ScoringWeights = {
      skills: (skills * factor) / 100,
      experience: (experience * factor) / 100,
      education: (education * factor) / 100,
      keywords: (keywords * factor) / 100,
      shortlistThreshold: threshold
    };
    onSaveWeights(newWeights);
    onClose();
  };

  const handleReset = () => {
    setSkills(40);
    setExperience(30);
    setEducation(15);
    setKeywords(15);
    setThreshold(75);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="glass-panel w-full max-w-lg rounded-2xl p-6 shadow-2xl border border-slate-800 animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <SlidersHorizontal className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">HR Scoring & Policy Weights</h2>
              <p className="text-xs text-slate-400">Tune algorithm weights for score calculation</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-5 text-slate-200 text-xs">
          
          {/* Total Weight Indicator */}
          <div className={`p-3 rounded-xl border flex items-center justify-between ${
            totalWeight === 100 ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
          }`}>
            <span className="font-semibold">Combined Relative Weight Total:</span>
            <span className="font-bold text-sm">{totalWeight}%</span>
          </div>

          {/* Skill Weight Slider */}
          <div>
            <div className="flex justify-between mb-1.5 font-semibold">
              <span className="text-slate-300">Technical Skills Fit Weight</span>
              <span className="text-blue-400 font-bold">{skills}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={skills}
              onChange={e => setSkills(parseInt(e.target.value))}
              className="w-full accent-blue-500 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Experience Weight Slider */}
          <div>
            <div className="flex justify-between mb-1.5 font-semibold">
              <span className="text-slate-300">Years of Experience Weight</span>
              <span className="text-blue-400 font-bold">{experience}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={experience}
              onChange={e => setExperience(parseInt(e.target.value))}
              className="w-full accent-blue-500 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Education Weight Slider */}
          <div>
            <div className="flex justify-between mb-1.5 font-semibold">
              <span className="text-slate-300">Education & Degree Level Weight</span>
              <span className="text-indigo-400 font-bold">{education}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={education}
              onChange={e => setEducation(parseInt(e.target.value))}
              className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Keywords Weight Slider */}
          <div>
            <div className="flex justify-between mb-1.5 font-semibold">
              <span className="text-slate-300">NLP Keyword Overlap (TF-IDF)</span>
              <span className="text-amber-400 font-bold">{keywords}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={keywords}
              onChange={e => setKeywords(parseInt(e.target.value))}
              className="w-full accent-amber-500 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <hr className="border-slate-800" />

          {/* Shortlist Threshold Slider */}
          <div>
            <div className="flex justify-between mb-1.5 font-semibold">
              <span className="text-slate-100 font-bold">Auto-Shortlist Score Threshold</span>
              <span className="text-emerald-400 font-bold text-sm">{threshold}%</span>
            </div>
            <p className="text-[11px] text-slate-400 mb-2">
              Candidates scoring equal to or above this percentage will be auto-flagged as Shortlisted.
            </p>
            <input
              type="range"
              min={50}
              max={95}
              value={threshold}
              onChange={e => setThreshold(parseInt(e.target.value))}
              className="w-full accent-emerald-500 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              onClick={handleReset}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-xl font-medium flex items-center gap-1.5"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Reset Defaults
            </button>

            <div className="flex gap-2">
              <button
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold rounded-xl flex items-center gap-2"
              >
                <Check className="h-4 w-4" /> Apply Weights & Recalculate
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
