import * as pdfjsLib from 'pdfjs-dist';
import mammoth from 'mammoth';
import type { SampleCandidateInput } from './mockData';

// Configure PDFjs worker URL
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

export async function parsePdfFile(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let fullText = '';

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const pageText = textContent.items
      .map((item: any) => item.str)
      .join(' ');
    fullText += pageText + '\n';
  }

  return fullText;
}

export async function parseDocxFile(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value;
}

export async function parseTxtFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string || '');
    reader.onerror = (e) => reject(e);
    reader.readAsText(file);
  });
}

// Smart heuristic entity extractor from raw resume text
export function extractCandidateMetadataFromText(
  fileName: string,
  rawText: string
): SampleCandidateInput {
  const lines = rawText.split('\n').map(l => l.trim()).filter(Boolean);

  // Name extraction heuristic: first line or filename clean up
  let name = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  if (lines.length > 0 && lines[0].length < 40 && !lines[0].toLowerCase().includes('resume')) {
    name = lines[0];
  }
  // Title Case Name
  name = name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');

  // Email extraction regex
  const emailMatch = rawText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
  const email = emailMatch ? emailMatch[0] : `${name.toLowerCase().replace(/\s+/g, '.')}@candidate.com`;

  // Phone extraction regex
  const phoneMatch = rawText.match(/(\+\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
  const phone = phoneMatch ? phoneMatch[0] : '+1 (555) 000-0000';

  // Location heuristic
  const locationMatch = rawText.match(/\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*),\s?([A-Z]{2})\b/);
  const location = locationMatch ? locationMatch[0] : 'Location Unspecified';

  // Years of Experience heuristic
  let YOE = 3;
  const yoeMatches = rawText.match(/(\d+)\+?\s*(?:years|yrs)\s*(?:of)?\s*experience/i);
  if (yoeMatches && yoeMatches[1]) {
    YOE = parseInt(yoeMatches[1], 10);
  } else {
    // Check graduation years or work history dates
    const years = rawText.match(/\b(19|20)\d{2}\b/g);
    if (years && years.length >= 2) {
      const minYr = Math.min(...years.map(Number));
      const maxYr = Math.max(...years.map(Number));
      const diff = maxYr - minYr;
      if (diff > 0 && diff < 30) YOE = diff;
    }
  }

  // Skills heuristic: scan common technical skills
  const commonTechSkills = [
    'React', 'TypeScript', 'JavaScript', 'Node.js', 'Python', 'LLM', 'REST APIs',
    'PostgreSQL', 'Git', 'Docker', 'Kubernetes', 'AWS', 'GraphQL', 'Tailwind CSS',
    'Vector Databases', 'LangChain', 'Java', 'C++', 'SQL', 'NoSQL', 'MongoDB',
    'Machine Learning', 'NLP', 'Data Analytics', 'Agile / Scrum', 'Product Strategy',
    'User Research', 'PyTorch', 'TensorFlow', 'FastAPI', 'Django'
  ];

  const detectedSkills = commonTechSkills.filter(skill => {
    const escaped = skill.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`\\b${escaped}\\b`, 'i');
    return regex.test(rawText);
  });

  // Education heuristic
  let education = "Bachelor's Degree";
  if (rawText.toLowerCase().includes('master') || rawText.toLowerCase().includes('m.s.')) {
    education = "Master's Degree in Related Field";
  } else if (rawText.toLowerCase().includes('ph.d') || rawText.toLowerCase().includes('doctorate')) {
    education = "Ph.D. in Computer Science / Related Field";
  } else if (rawText.toLowerCase().includes('bachelor') || rawText.toLowerCase().includes('b.s.')) {
    education = "Bachelor's Degree in Computer Science / Engineering";
  }

  return {
    name,
    email,
    phone,
    location,
    currentRole: lines.find(l => l.toLowerCase().includes('engineer') || l.toLowerCase().includes('developer') || l.toLowerCase().includes('manager')) || 'Software Professional',
    yearsOfExperience: YOE,
    education,
    skills: detectedSkills.length > 0 ? detectedSkills : ['JavaScript', 'Problem Solving', 'Communication'],
    resumeText: rawText
  };
}
